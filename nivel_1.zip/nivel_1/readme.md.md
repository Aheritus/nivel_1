nivel_1/
├── pdv.py       (o código em Python)
└── README.md    (esse textinho aqui)
#########################################

# Desafio Nível 1 — PDV com Descontos (Python)

## Objetivo
Fala aí! Esse projeto é um sistema simples de caixa de loja (PDV) feito em Python. A ideia é registrar as compras dos clientes, calcular os descontos (por idade e por valor), guardar tudo numa lista e, no final, mostrar um resumo de quanto foi vendido, quanto de desconto foi dado e quanto entrou no caixa de verdade.

## Como funciona o programa?
O código foi feito bem passo a passo, sem complicação. Ele funciona assim:
1. O programa pede o valor da compra e a idade do cliente.
2. Ele valida os dados (se você digitar valor ou idade negativa, ele avisa e pede de novo).
3. Se o cliente tiver 65 anos ou mais, ele já aplica 20% de desconto.
4. Depois, ele olha se o valor (já com o desconto de idade) passou de R$ 100,00.
5. Se passou, ele manda mais 10% de desconto em cima desse valor.
6. Guarda os dados da compra numa lista (usando o famoso `.append()`).
7. Fica nesse looping pedindo compras até você digitar `0`.
8. Quando você digita `0`, ele encerra as compras e mostra o resumo final na tela.

## Como rodar o programa
Abre o terminal (ou o próprio PyCharm), entra na pasta `nivel_1` e digita:
```bash
python pdv.py
################################################################################
#	Valor original	Idade	Desconto Idade	Desconto Valor	Valor final esperado
1	R$ 50.00	30	0%	0%	R$ 50.00
2	R$ 100.00	30	0%	0%	R$ 100.00
3	R$ 80.00	65	20%	0%	R$ 64.00
4	R$ 100.00	70	20%	0%	R$ 80.00
5	R$ 125.00	70	20%	0%	R$ 100.00
6	R$ 200.00	30	0%	10%	R$ 180.00
7	R$ 101.00	30	0%	10%	R$ 90.90
8	R$ 200.00	65	20%	10%	R$ 144.00
9	R$ 1000.00	80	20%	10%	R$ 720.00
10	R$ 200.00	64	0%	10%	R$ 180.00
usei essa tabela como teste.
