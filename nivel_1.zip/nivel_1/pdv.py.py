compras = []

print("=" * 50)
print("   PDV COM DESCONTOS - Digite 0 para encerrar")
print("=" * 50)

valor = float(input("\nDigite o valor da compra (ou 0 para encerrar): R$ "))

while valor != 0:
    while valor < 0:
        print("AVISO: O valor da compra não pode ser negativo!")
        valor = float(input("Digite novamente o valor da compra (ou 0 para encerrar): R$ "))

    if valor == 0:
        break

    idade = int(input("Digite a idade do cliente: "))

    while idade < 0:
        print("AVISO: A idade não pode ser negativa!")
        idade = int(input("Digite novamente a idade do cliente: "))

    valor_original = valor
    valor_com_desconto_idade = valor_original

    # Regra 1
    if idade >= 65:
        valor_com_desconto_idade = valor_original * 0.80
        print(f">>> Desconto por idade (20%) aplicado: -R$ {valor_original - valor_com_desconto_idade:.2f}")

    # Regra 2
    if valor_com_desconto_idade > 100.0:
        valor_final = valor_com_desconto_idade * 0.90
        print(f">>> Desconto por valor (10%) aplicado: -R$ {valor_com_desconto_idade - valor_final:.2f}")
    else:
        valor_final = valor_com_desconto_idade

    desconto_total = valor_original - valor_final

    print("-" * 50)
    print(f"Valor original:   R$ {valor_original:.2f}")
    print(f"Idade do cliente: {idade} anos")
    print(f"Desconto total:   R$ {desconto_total:.2f}")
    print(f"Valor final:      R$ {valor_final:.2f}")
    print("-" * 50)

    compras.append({
        "valor_original": valor_original,
        "idade": idade,
        "desconto": desconto_total,
        "valor_final": valor_final
    })

    valor = float(input("\nDigite o valor da próxima compra (ou 0 para encerrar): R$ "))

print("\n" + "=" * 50)
print("            RESUMO FINAL DAS COMPRAS")
print("=" * 50)

quantidade = len(compras)
total_bruto = 0.0
total_desconto = 0.0
total_final = 0.0

for compra in compras:
    total_bruto = total_bruto + compra["valor_original"]
    total_desconto = total_desconto + compra["desconto"]
    total_final = total_final + compra["valor_final"]

print(f"Quantidade de compras: {quantidade}")
print(f"Total bruto:           R$ {total_bruto:.2f}")
print(f"Total de descontos:    R$ {total_desconto:.2f}")
print(f"Total final:           R$ {total_final:.2f}")
print("=" * 50)
print("Programa encerrado. Obrigado!")